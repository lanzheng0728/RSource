# R Statistics Essential Training
# Ex05_01
# Selecting cases
