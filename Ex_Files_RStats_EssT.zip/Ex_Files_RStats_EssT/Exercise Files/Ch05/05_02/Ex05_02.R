# R Statistics Essential Training
# Ex05_02
# Analyzing by subgroups
