# R Statistics Essential Training
# Ex06_01
# Creating bar charts of group means
