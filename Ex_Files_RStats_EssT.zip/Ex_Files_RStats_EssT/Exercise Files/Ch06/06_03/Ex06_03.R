# R Statistics Essential Training
# Ex06_03
# Creating scatterplots
