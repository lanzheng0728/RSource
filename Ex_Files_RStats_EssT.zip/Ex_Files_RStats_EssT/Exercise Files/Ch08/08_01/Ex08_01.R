# R Statistics Essential Training
# Ex08_01
# Creating clustered bar chart for frequencies
