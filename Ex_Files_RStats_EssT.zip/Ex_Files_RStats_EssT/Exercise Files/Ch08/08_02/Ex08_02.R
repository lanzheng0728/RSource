# R Statistics Essential Training
# Ex08_02
# Creating scatterplots for grouped data

