# R Statistics Essential Training
# Ex07_01
# Calculating correlations
