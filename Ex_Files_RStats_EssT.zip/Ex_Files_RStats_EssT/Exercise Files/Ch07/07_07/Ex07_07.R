# R Statistics Essential Training
# Ex07_07
# Creating crosstabs for categorical variables
