# R Statistics Essential Training
# Ex07_08
# Computing robust statistics for bivariate associations

