# R Statistics Essential Training
# Ex07_04
# Comparing paired means: Paired t-test
