# R Statistics Essential Training
# Ex01_04
# Installing and managing packages

