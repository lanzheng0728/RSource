# R Statistics Essential Training
# Ex01_07
# Importing data
