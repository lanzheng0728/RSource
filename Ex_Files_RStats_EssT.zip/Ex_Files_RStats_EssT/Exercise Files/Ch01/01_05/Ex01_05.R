# R Statistics Essential Training
# Ex01_05
# Using R’s built-in datasets
