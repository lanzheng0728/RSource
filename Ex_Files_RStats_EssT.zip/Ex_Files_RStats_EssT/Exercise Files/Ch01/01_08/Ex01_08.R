# R Statistics Essential Training
# Ex01_08
# Converting tabular data to row data
