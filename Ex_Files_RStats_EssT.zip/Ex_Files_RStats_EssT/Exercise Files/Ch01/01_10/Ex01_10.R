# R Statistics Essential Training
# Ex01_10
# Exploring Color with RColorBrewer
