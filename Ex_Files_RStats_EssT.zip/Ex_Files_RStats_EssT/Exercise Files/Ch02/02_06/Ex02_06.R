# R Statistics Essential Training
# Ex02_06
# Exporting charts
