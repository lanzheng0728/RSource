# R Statistics Essential Training
# Ex02_01
# Creating bar charts for categorical variables
