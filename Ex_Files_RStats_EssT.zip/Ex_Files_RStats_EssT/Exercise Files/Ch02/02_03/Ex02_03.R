# R Statistics Essential Training
# Ex02_03
# Creating histograms for quantitative variables
