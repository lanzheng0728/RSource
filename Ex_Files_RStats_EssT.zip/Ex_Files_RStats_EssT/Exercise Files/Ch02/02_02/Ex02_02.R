# R Statistics Essential Training
# Ex02_02
# Creating pie charts for categorical variables
