# R Statistics Essential Training
# Ex03_03
# Single proportion: Hypothesis test and confidence interval
