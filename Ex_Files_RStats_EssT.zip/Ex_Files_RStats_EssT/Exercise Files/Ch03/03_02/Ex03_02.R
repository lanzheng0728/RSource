# R Statistics Essential Training
# Ex03_02
# Calculating descriptives
