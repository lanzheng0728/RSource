# R Statistics Essential Training
# Ex03_06
# Robust statistics for univariate analyses
