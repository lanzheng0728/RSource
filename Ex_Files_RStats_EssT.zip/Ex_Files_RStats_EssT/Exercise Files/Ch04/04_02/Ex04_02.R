# R Statistics Essential Training
# Ex04_02
# Transforming variables
