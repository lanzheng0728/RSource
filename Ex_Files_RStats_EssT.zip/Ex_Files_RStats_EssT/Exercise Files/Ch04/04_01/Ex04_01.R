# R Statistics Essential Training
# Ex04_01
# Examining outliers
